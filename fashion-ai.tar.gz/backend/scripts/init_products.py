"""
상품 데이터 초기화 스크립트
더미 상품 데이터를 SQL 데이터베이스에 저장하고 임베딩을 생성합니다.
"""
import sys
import os
import asyncio
import json

# 프로젝트 루트 경로 추가
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from sqlalchemy.orm import Session
from app.database import get_db, engine
from app.models.db_models import Product, Base
from ml.vector_search import SearchEngine
from app.core.logging import get_logger

# 추가 상품 생성 함수 import
import sys
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)
from generate_products import generate_additional_products

logger = get_logger(__name__)

# 더미 상품 데이터 (frontend/src/data/dummyProducts.js에서 가져옴)
DUMMY_PRODUCTS = [
    {
        "id": "prod_001",
        "name": "오버핏 후드티",
        "brand": "무신사 Style",
        "category": "상의",
        "gender": "남성",
        "style_tags": ["무신사 감성", "스트릿", "오버핏"],
        "color": "블랙",
        "price": 89000,
        "popularity_score": 0.92,
        "image_url": "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop",
        "description": "편안한 착용감의 오버핏 후드티입니다. 넉넉한 핏으로 캐주얼하게 연출할 수 있습니다.",
        "season": "사계절",
        "situation": "데일리"
    },
    {
        "id": "prod_002",
        "name": "슬림핏 청바지",
        "brand": "29CM Studio",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["29CM 감성", "미니멀", "슬림핏"],
        "color": "인디고",
        "price": 129000,
        "popularity_score": 0.88,
        "image_url": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&h=800&fit=crop",
        "description": "핏이 좋은 슬림핏 청바지입니다. 데일리로 활용하기 좋은 기본 아이템입니다.",
        "season": "사계절",
        "situation": "데일리"
    },
    {
        "id": "prod_003",
        "name": "크롭 가디건",
        "brand": "29CM Studio",
        "category": "상의",
        "gender": "여성",
        "style_tags": ["29CM 감성", "미니멀", "크롭"],
        "color": "베이지",
        "price": 149000,
        "popularity_score": 0.85,
        "image_url": "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=800&fit=crop",
        "description": "트렌디한 크롭 가디건입니다. 레이어드 스타일링에 완벽합니다.",
        "season": "봄",
        "situation": "데일리"
    },
    {
        "id": "prod_004",
        "name": "와이드 슬랙스",
        "brand": "Office Wear",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["오피스", "미니멀", "와이드"],
        "color": "네이비",
        "price": 179000,
        "popularity_score": 0.82,
        "image_url": "https://images.unsplash.com/photo-1594938291221-94f18dd6d221?w=600&h=800&fit=crop",
        "description": "편안한 착용감의 와이드 슬랙스입니다. 오피스룩에 활용하기 좋습니다.",
        "season": "사계절",
        "situation": "출근"
    },
    {
        "id": "prod_005",
        "name": "레더 재킷",
        "brand": "Street Brand",
        "category": "아우터",
        "gender": "남성",
        "style_tags": ["스트릿", "레더", "오버핏"],
        "color": "블랙",
        "price": 299000,
        "popularity_score": 0.90,
        "image_url": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop",
        "description": "시크한 레더 재킷입니다. 스트릿 스타일을 완성해줍니다."
    },
    {
        "id": "prod_006",
        "name": "플리츠 스커트",
        "brand": "Feminine",
        "category": "하의",
        "gender": "여성",
        "style_tags": ["페미닌", "미니멀", "플리츠"],
        "color": "화이트",
        "price": 119000,
        "popularity_score": 0.78,
        "image_url": "https://images.unsplash.com/photo-1594633313593-bab3825d0caf?w=600&h=800&fit=crop",
        "description": "우아한 플리츠 스커트입니다. 여성스러운 스타일링에 적합합니다."
    },
    {
        "id": "prod_007",
        "name": "후드 집업",
        "brand": "Street Brand",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["스트릿", "캐주얼", "후드"],
        "color": "그레이",
        "price": 159000,
        "popularity_score": 0.87,
        "image_url": "https://images.unsplash.com/photo-1556821843-3a63f95609a7?w=600&h=800&fit=crop",
        "description": "편안한 후드 집업입니다. 캐주얼 데일리룩에 완벽합니다."
    },
    {
        "id": "prod_008",
        "name": "셔츠 원피스",
        "brand": "Office Wear",
        "category": "원피스",
        "gender": "여성",
        "style_tags": ["오피스", "미니멀", "셔츠"],
        "color": "화이트",
        "price": 199000,
        "popularity_score": 0.83,
        "image_url": "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&h=800&fit=crop",
        "description": "깔끔한 셔츠 원피스입니다. 비즈니스 캐주얼룩에 활용하기 좋습니다."
    },
    {
        "id": "prod_009",
        "name": "카고 팬츠",
        "brand": "Street Brand",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["스트릿", "캐주얼", "카고"],
        "color": "카키",
        "price": 139000,
        "popularity_score": 0.80,
        "image_url": "https://images.unsplash.com/photo-1506629905862-4c94c8ebf58c?w=600&h=800&fit=crop",
        "description": "실용적인 카고 팬츠입니다. 수납공간이 넉넉합니다."
    },
    {
        "id": "prod_010",
        "name": "니트 스웨터",
        "brand": "Minimal Style",
        "category": "상의",
        "gender": "공용",
        "style_tags": ["미니멀", "캐주얼", "니트"],
        "color": "크림",
        "price": 169000,
        "popularity_score": 0.86,
        "image_url": "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=800&fit=crop",
        "description": "부드러운 니트 스웨터입니다. 따뜻하면서도 세련된 디자인입니다."
    },
    {
        "id": "prod_011",
        "name": "트레이닝 조거",
        "brand": "Sporty",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["스포티", "캐주얼", "조거"],
        "color": "블랙",
        "price": 99000,
        "popularity_score": 0.79,
        "image_url": "https://images.unsplash.com/photo-1506629905862-4c94c8ebf58c?w=600&h=800&fit=crop",
        "description": "편안한 트레이닝 조거입니다. 운동과 일상 모두에 적합합니다."
    },
    {
        "id": "prod_012",
        "name": "트렌치 코트",
        "brand": "Classic",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["클래식", "미니멀", "트렌치"],
        "color": "베이지",
        "price": 399000,
        "popularity_score": 0.91,
        "image_url": "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=600&h=800&fit=crop",
        "description": "클래식한 트렌치 코트입니다. 타임리스한 디자인으로 오래 입을 수 있습니다."
    },
    {
        "id": "prod_013",
        "name": "반팔 티셔츠",
        "brand": "Basic",
        "category": "상의",
        "gender": "공용",
        "style_tags": ["베이직", "캐주얼", "반팔"],
        "color": "화이트",
        "price": 39000,
        "popularity_score": 0.75,
        "image_url": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop",
        "description": "베이직한 반팔 티셔츠입니다. 다양한 스타일링의 베이스 아이템으로 활용하기 좋습니다.",
        "season": "여름",
        "situation": "데일리"
    },
    {
        "id": "prod_014",
        "name": "데님 셔츠",
        "brand": "Denim Co",
        "category": "상의",
        "gender": "남성",
        "style_tags": ["캐주얼", "데님", "셔츠"],
        "color": "라이트블루",
        "price": 109000,
        "popularity_score": 0.84,
        "image_url": "https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?w=600&h=800&fit=crop",
        "description": "캐주얼한 데님 셔츠입니다. 레이어드나 단독 착용 모두 가능합니다."
    },
    {
        "id": "prod_015",
        "name": "슬림핏 슬랙스",
        "brand": "Office Wear",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["오피스", "슬림핏", "정장"],
        "color": "차콜",
        "price": 189000,
        "popularity_score": 0.88,
        "image_url": "https://images.unsplash.com/photo-1594938291221-94f18dd6d221?w=600&h=800&fit=crop",
        "description": "정장용 슬림핏 슬랙스입니다. 비즈니스룩에 완벽하게 어울립니다."
    },
    {
        "id": "prod_016",
        "name": "맨투맨",
        "brand": "Street Brand",
        "category": "상의",
        "gender": "남성",
        "style_tags": ["스트릿", "캐주얼", "맨투맨"],
        "color": "그레이",
        "price": 79000,
        "popularity_score": 0.81,
        "image_url": "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop",
        "description": "편안한 맨투맨입니다. 데일리 베이스 아이템으로 활용하기 좋습니다."
    },
    {
        "id": "prod_017",
        "name": "코치 재킷",
        "brand": "Sporty",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["스포티", "캐주얼", "코치"],
        "color": "네이비",
        "price": 219000,
        "popularity_score": 0.87,
        "image_url": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop",
        "description": "스포티한 코치 재킷입니다. 활동적인 스타일에 적합합니다."
    },
    {
        "id": "prod_018",
        "name": "플레어 스커트",
        "brand": "Feminine",
        "category": "하의",
        "gender": "여성",
        "style_tags": ["페미닌", "플레어", "스커트"],
        "color": "핑크",
        "price": 139000,
        "popularity_score": 0.76,
        "image_url": "https://images.unsplash.com/photo-1594633313593-bab3825d0caf?w=600&h=800&fit=crop",
        "description": "우아한 플레어 스커트입니다. 여성스러운 실루엣이 특징입니다."
    },
    {
        "id": "prod_019",
        "name": "후드 스웨트셔츠",
        "brand": "Street Brand",
        "category": "상의",
        "gender": "공용",
        "style_tags": ["스트릿", "캐주얼", "후드"],
        "color": "네이비",
        "price": 119000,
        "popularity_score": 0.83,
        "image_url": "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop",
        "description": "따뜻한 후드 스웨트셔츠입니다. 캐주얼한 스타일링에 완벽합니다."
    },
    {
        "id": "prod_020",
        "name": "와이드 데님",
        "brand": "Denim Co",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["캐주얼", "데님", "와이드"],
        "color": "인디고",
        "price": 149000,
        "popularity_score": 0.85,
        "image_url": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&h=800&fit=crop",
        "description": "트렌디한 와이드 데님입니다. 넉넉한 핏으로 편안하게 착용할 수 있습니다."
    },
    {
        "id": "prod_021",
        "name": "크롭 티셔츠",
        "brand": "Minimal Style",
        "category": "상의",
        "gender": "여성",
        "style_tags": ["미니멀", "크롭", "티셔츠"],
        "color": "화이트",
        "price": 59000,
        "popularity_score": 0.77,
        "image_url": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop",
        "description": "트렌디한 크롭 티셔츠입니다. 하이웨이스트 팬츠와 조합하기 좋습니다."
    },
    {
        "id": "prod_022",
        "name": "부츠컷 팬츠",
        "brand": "Feminine",
        "category": "하의",
        "gender": "여성",
        "style_tags": ["페미닌", "부츠컷", "팬츠"],
        "color": "베이지",
        "price": 159000,
        "popularity_score": 0.79,
        "image_url": "https://images.unsplash.com/photo-1506629905862-4c94c8ebf58c?w=600&h=800&fit=crop",
        "description": "우아한 부츠컷 팬츠입니다. 레트로 감성이 느껴지는 디자인입니다."
    },
    {
        "id": "prod_023",
        "name": "패딩 재킷",
        "brand": "Sporty",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["스포티", "패딩", "재킷"],
        "color": "블랙",
        "price": 349000,
        "popularity_score": 0.89,
        "image_url": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop",
        "description": "따뜻한 패딩 재킷입니다. 겨울철 아우터로 완벽합니다."
    },
    {
        "id": "prod_024",
        "name": "린넨 셔츠",
        "brand": "Office Wear",
        "category": "상의",
        "gender": "공용",
        "style_tags": ["오피스", "린넨", "셔츠"],
        "color": "아이보리",
        "price": 129000,
        "popularity_score": 0.82,
        "image_url": "https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?w=600&h=800&fit=crop",
        "description": "시원한 린넨 셔츠입니다. 여름철 오피스룩에 활용하기 좋습니다."
    },
    {
        "id": "prod_025",
        "name": "치마 바지",
        "brand": "Feminine",
        "category": "하의",
        "gender": "여성",
        "style_tags": ["페미닌", "치마바지", "팬츠"],
        "color": "블랙",
        "price": 149000,
        "popularity_score": 0.80,
        "image_url": "https://images.unsplash.com/photo-1594633313593-bab3825d0caf?w=600&h=800&fit=crop",
        "description": "우아한 치마 바지입니다. 여성스러우면서도 실용적인 디자인입니다."
    },
    {
        "id": "prod_026",
        "name": "후드 코트",
        "brand": "Street Brand",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["스트릿", "후드", "코트"],
        "color": "카키",
        "price": 279000,
        "popularity_score": 0.86,
        "image_url": "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=600&h=800&fit=crop",
        "description": "시크한 후드 코트입니다. 캐주얼하면서도 세련된 스타일을 연출할 수 있습니다."
    },
    {
        "id": "prod_027",
        "name": "터틀넥 니트",
        "brand": "Minimal Style",
        "category": "상의",
        "gender": "공용",
        "style_tags": ["미니멀", "니트", "터틀넥"],
        "color": "네이비",
        "price": 179000,
        "popularity_score": 0.84,
        "image_url": "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=800&fit=crop",
        "description": "부드러운 터틀넥 니트입니다. 목 부분까지 따뜻하게 보호해줍니다."
    },
    {
        "id": "prod_028",
        "name": "스키니 진",
        "brand": "Denim Co",
        "category": "하의",
        "gender": "남성",
        "style_tags": ["캐주얼", "데님", "스키니"],
        "color": "블랙",
        "price": 139000,
        "popularity_score": 0.88,
        "image_url": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&h=800&fit=crop",
        "description": "핏이 좋은 스키니 진입니다. 슬림한 실루엣으로 다리 라인을 예쁘게 보여줍니다."
    },
    {
        "id": "prod_029",
        "name": "바람막이",
        "brand": "Sporty",
        "category": "아우터",
        "gender": "공용",
        "style_tags": ["스포티", "바람막이", "재킷"],
        "color": "네이비",
        "price": 189000,
        "popularity_score": 0.85,
        "image_url": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop",
        "description": "가벼운 바람막이입니다. 활동적인 스타일에 적합하며 날씨를 막아줍니다."
    },
    {
        "id": "prod_030",
        "name": "플리츠 원피스",
        "brand": "Feminine",
        "category": "원피스",
        "gender": "여성",
        "style_tags": ["페미닌", "플리츠", "원피스"],
        "color": "핑크",
        "price": 229000,
        "popularity_score": 0.81,
        "image_url": "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&h=800&fit=crop",
        "description": "우아한 플리츠 원피스입니다. 여성스러운 스타일링에 완벽한 원피스입니다."
    }
]


async def init_products():
    """상품 데이터를 SQL에 저장하고 임베딩을 생성합니다."""
    try:
        # 데이터베이스 테이블 생성
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created")
        
        # 데이터베이스 세션 생성
        db = next(get_db())
        
        try:
            # SearchEngine 초기화 (임베딩 생성용)
            search_engine = SearchEngine(db=db)
            
            # 추가 상품 데이터 생성 (200개)
            additional_products = generate_additional_products()
            
            # 전체 상품 데이터 합치기
            all_products = DUMMY_PRODUCTS + additional_products
            
            logger.info(f"Starting product initialization... Total products: {len(all_products)}")
            logger.info(f"  - Base products: {len(DUMMY_PRODUCTS)}")
            logger.info(f"  - Additional products: {len(additional_products)}")
            
            # 상품 데이터 인덱싱 (임베딩 생성 및 SQL 저장)
            success = await search_engine.index_products(all_products)
            
            if success:
                logger.info(f"Successfully initialized {len(all_products)} products")
                
                # 저장된 상품 수 확인
                product_count = db.query(Product).count()
                logger.info(f"Total products in database: {product_count}")
                
                return True
            else:
                logger.error("Failed to index products")
                return False
                
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error initializing products: {e}", exc_info=True)
        return False


if __name__ == "__main__":
    """스크립트 직접 실행 시"""
    result = asyncio.run(init_products())
    if result:
        print("✅ 상품 데이터 초기화 완료!")
        sys.exit(0)
    else:
        print("❌ 상품 데이터 초기화 실패")
        sys.exit(1)

